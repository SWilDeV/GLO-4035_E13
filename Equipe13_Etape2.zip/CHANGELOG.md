# CHANGELOG V1

## Corrections Application
### Requete /heartbeat:
    Changement de la forme key/value de la réponse: nouveau format: "villeChoisie": "Montréal"


## Corrections Rapport

- Section 2B - description de données révisé et bonifié

- Section 3B : ajout d'une justification pour les principes de fiabilité, de maintenabilité et d'extensibilité révisés pour le language utilisé

- Professionnalismes: Correction du niveau de français.